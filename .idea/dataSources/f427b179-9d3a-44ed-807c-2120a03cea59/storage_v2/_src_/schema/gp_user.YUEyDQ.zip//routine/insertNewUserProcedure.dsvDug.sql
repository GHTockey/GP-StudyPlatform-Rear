create
    definer = root@localhost procedure insertNewUserProcedure(IN p_username varchar(255), IN p_password varchar(255),
                                                              IN p_avatar varchar(255), IN p_email varchar(255))
BEGIN
    DECLARE next_id CHAR(6);

    SELECT LPAD(IFNULL(MAX(SUBSTRING(id, 2) + 1), 1), 6, '0')
    INTO next_id
    FROM users;

    INSERT INTO users (id, username, `password`, avatar, email)
    VALUES (CONCAT('U', next_id), p_username, p_password, p_avatar, p_email);
END;

